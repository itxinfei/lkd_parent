/*
Navicat MySQL Data Transfer

Source Server         : 立可得V2
Source Server Version : 80020
Source Host           : 172.17.0.87:3306
Source Database       : lkd_status

Target Server Type    : MYSQL
Target Server Version : 80020
File Encoding         : 65001

Date: 2021-02-05 13:02:05
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for tb_status_type
-- ----------------------------
DROP TABLE IF EXISTS `tb_status_type`;
CREATE TABLE `tb_status_type` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'id',
  `status_code` varchar(10) DEFAULT NULL COMMENT '状态代码',
  `descr` varchar(20) DEFAULT NULL COMMENT '状态描述',
  PRIMARY KEY (`id`),
  UNIQUE KEY `StatusType_StatusCode_uindex` (`status_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of tb_status_type
-- ----------------------------
INSERT INTO `tb_status_type` VALUES ('1', '10001', '断网');
INSERT INTO `tb_status_type` VALUES ('2', '10002', '设备故障');
INSERT INTO `tb_status_type` VALUES ('3', '10003', '缺货');

-- ----------------------------
-- Table structure for tb_vm_status_info
-- ----------------------------
DROP TABLE IF EXISTS `tb_vm_status_info`;
CREATE TABLE `tb_vm_status_info` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `inner_code` varchar(15) DEFAULT NULL COMMENT '售货机编号',
  `status_code` varchar(10) DEFAULT NULL COMMENT '售货机状态码',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `utime` datetime DEFAULT NULL COMMENT '发生时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of tb_vm_status_info
-- ----------------------------
